 package model;
  
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
    
@Entity 
@Table(name="Bean")
public class Bean { 
	@Id
	@Column
	private int pid;
	private String pname;
	@Transient 
	 private List<MultipartFile> image; 
	public Bean()
	{    
	 	          
	}    
	public List<MultipartFile> getImage() {
		return image;
	}

	public void setImage(List<MultipartFile> image) {
		this.image = image;
	}

	public Bean(int id,String name){
		this.pid=id;
		this.pname=name;
		}
	public int getPid() {
	return pid;
}

	public void setPid(int pid) {
	this.pid = pid;
}

	public String getPname() {
	return pname;
}

	public void setPname(String pname) {
	this.pname = pname;
}

}
