package serviceLayer;

import java.util.List;

import model.LoginBean;

public interface UserServiceInter {
	public void addUser(LoginBean ud);
	public void updateUser(LoginBean ud);
	public void removeUser(int uid);
	public List<LoginBean> listUser();
	public LoginBean getUserbyId(int uid);
}
 