package serviceLayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import daoLayer.UserDao;
import model.LoginBean;

@Service
@Transactional
public class UserService implements UserServiceInter{

	@Autowired 
	UserDao us; 

	public void addUser(LoginBean ud) {
		us.addUser(ud);
		
	}

	public void updateUser(LoginBean ud) {
		us.updateUser(ud);
		
	}

	public void removeUser(int uid) {
		us.removeUSer(uid);
		
	}

	public List<LoginBean> listUser() {
		return us.getUser();
	}

	public LoginBean getUserbyId(int uid) {
		
		return us.getUserbyId(uid);
	}
	 

}
