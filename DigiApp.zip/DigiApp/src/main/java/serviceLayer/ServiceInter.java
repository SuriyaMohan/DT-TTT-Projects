package serviceLayer;

import java.util.List;

import model.Bean;

public interface ServiceInter {
	 public void addProd(Bean bean);
	    public int updateProd(Bean bean);
	    public List<Bean> listProds(); 
	    public Bean getProdById(Integer bid);
	    public int removeProd(Integer bid);
 } 
 