package serviceLayer;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import daoLayer.*;
import model.*; 

@Service
public class ProdService implements ServiceInter{
   
	@Autowired
	DaoInter ds;
	  public ProdService(){
			  
		  }
	public void addProd(Bean bean) {
				ds.addProd(bean);
	}

	  	public int updateProd(Bean bean) {
		return ds.updateProd(bean);
		 
	}

	public List<Bean> listProds() {
		return ds.listProds();
	}
	public Bean getProdById(Integer bid) {
		return ds.getProdById(bid);
	}
	public int removeProd(Integer bid) {
		return ds.removeProd(bid);
	}
	
}
