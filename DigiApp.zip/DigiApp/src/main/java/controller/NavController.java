 package controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream; 
import java.nio.file.Path; 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.google.gson.Gson;
import daoLayer.DaoService;
import daoLayer.UserDao;
import model.Bean;
import model.LoginBean;
import serviceLayer.ProdService;
import serviceLayer.ServiceInter;
import serviceLayer.UserService;
import serviceLayer.UserServiceInter;
 
@Controller
public class NavController {
	@Autowired
	ProdService ps;
	 UserService usi;
	String s="";
	List<Bean>  list=new ArrayList<Bean>();

	public NavController(){
		
	} 
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	@RequestMapping("signup")
	public ModelAndView sigUp()throws Exception
			{
		ModelAndView mv = new ModelAndView("signup");
		return mv;
	}
	@RequestMapping("loginpage")
	public ModelAndView orderPage()throws Exception
			{
		ModelAndView mv = new ModelAndView("login");
		return mv;
	} 
	@RequestMapping("moreInfo")
	public ModelAndView infoPage()throws Exception
			{
		ModelAndView mv = new ModelAndView("products");
		return mv;
	}
	 @RequestMapping(value="/listprod", method = RequestMethod.GET)
	 public ModelAndView listEmployees() {
	      list=ps.listProds();
		 return new ModelAndView("list","bean1", list); 
	 }
	 @RequestMapping(value = "/addProd", method = RequestMethod.GET)
	 public ModelAndView addProduct(@ModelAttribute("command") Bean command) {
	  Map<String, Object> model = new HashMap<String, Object>();
	  model.put("employees", ps.listProds());
	  return new ModelAndView("add", model);   
	 }  
	 
@ModelAttribute("pro")
public @ResponseBody Bean createProduct()
{
 return new Bean(); 
}
	 	
@RequestMapping(value = "save", method = RequestMethod.POST) 
public ModelAndView saveProduct(@ModelAttribute("pro") Bean pro, HttpServletRequest request,BindingResult result) {
	ps.addProd(pro);//calls service method
	System.out.println("Added");
	return new ModelAndView("add");
	} 
 
@RequestMapping(value = "/delete/{pid}", method = RequestMethod.GET)
public ModelAndView editProduct(@RequestParam int id,@ModelAttribute("user") Bean user, BindingResult result) {
  ps.updateProd(user);
  System.out.println("Edited");
  return new ModelAndView(); 
 } 
  
@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
public ModelAndView deleteProduct(@RequestParam int id,@ModelAttribute("user") Bean user,BindingResult result) {
 int d=ps.removeProd(id);
 System.out.println("deleted" + d + "successfully");
	return new ModelAndView("deleted");
 }
//Spring SEcurity
@RequestMapping(value = { "/" ,"/Welcome**"}, method = RequestMethod.GET)
public ModelAndView defaultPage() {

  ModelAndView model = new ModelAndView();
  model.addObject("title", "Spring Security Login Form - Database Authentication");
  model.addObject("message", "This is default page!");
  model.setViewName("index");
  return model;
} 
@RequestMapping(value = "/login", method = RequestMethod.GET)
public ModelAndView login(@RequestParam(value = "error", required = false) String error,
	@RequestParam(value = "logout", required = false) String logout) {

  ModelAndView model = new ModelAndView();
  if (error != null) {
	model.addObject("error", "Invalid username and password!");
  } 

  if (logout != null) {
	model.addObject("msg", "You've been logged out successfully.");
  }
  model.setViewName("login");

  return model;
}
//for 403 access denied page
@RequestMapping(value = "/403", method = RequestMethod.GET)
public ModelAndView accesssDenied() {

  ModelAndView model = new ModelAndView();
	
  //check if user is login
  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
  if (!(auth instanceof AnonymousAuthenticationToken)) {
	UserDetails userDetail = (UserDetails) auth.getPrincipal();	
	model.addObject("username", userDetail.getUsername());
  }

  model.setViewName("403");
  return model;
}

@RequestMapping(value = "/admin", method = RequestMethod.GET)
public ModelAndView adminPage() {

  ModelAndView model = new ModelAndView();
  model.addObject("title", "Spring Security Login Form - Database Authentication");
  model.addObject("message", "This page is for ROLE_ADMIN only!");
  model.setViewName("products"); 
  return model;

}
    @RequestMapping("prodesc")
	public ModelAndView showMessage(@RequestParam String a)throws Exception
			{
		s=a;
		ModelAndView mv = new ModelAndView("desc");
		return mv;
	}
	 
	@RequestMapping("/ProductsVw")
	public @ResponseBody String productDetails()
	{
	 
		//int i=Integer.parseInt(s);
		if(s.equals("222")|| s.equals("333")||s.equals("444")){
			List<Bean> list=new ArrayList<Bean>();
			Bean b=ps.getProdById(Integer.parseInt(s));
			list.add(b);
		}
		 if(s.equals("asd")){
			List<Bean> list=new ArrayList<Bean>();
			list=ps.listProds();
		}
		Gson gs=new Gson();
		String val=gs.toJson(list);
	    return val;
	}

}
