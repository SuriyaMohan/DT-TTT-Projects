package daoLayer;

import java.util.List;
import model.LoginBean;

public interface UserDao {
	public void addUser(LoginBean ud);
	public void updateUser(LoginBean ud);
	public void removeUSer(int uid);
	public List<LoginBean> getUser();
	public LoginBean getUserbyId(int uid);
}
 