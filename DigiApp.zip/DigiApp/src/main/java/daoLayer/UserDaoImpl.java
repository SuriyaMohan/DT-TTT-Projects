package daoLayer;

import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import model.Bean;
import model.LoginBean;


@Repository 
@Transactional
public class UserDaoImpl implements UserDao {
	private List<LoginBean> listUser;
	 
	 @Autowired
	 SessionFactory sessionFactory;
	 
	 public void addUser(LoginBean ud) 
	 { 
		 Session sess=sessionFactory.openSession();
			Transaction tx=(Transaction)sess.beginTransaction();
			sess.save(ud);
			//tx.commit();
			sess.close();
			System.out.println("successssss valu is "+ud.getUrole());
		}
		public void updateUser(LoginBean ud) {
			Session sess=sessionFactory.openSession();
			Transaction trx=(Transaction)sess.beginTransaction();
			sess.saveOrUpdate(ud);
			//trx.commit();
			sess.close();
		}
		public void removeUSer(int uid) {
			Session sess=sessionFactory.openSession();
			Transaction trx=(Transaction)sess.beginTransaction();
			
			LoginBean  ud=(LoginBean)sess.load(LoginBean.class,uid );
				sess.delete(ud);
			
				//trx.commit();
			sess.close();
		}
		public List<LoginBean> getUser() {
			Session sess=sessionFactory.openSession();
			listUser=sess.createQuery("from UserDetail").list();
			return listUser;
		}
			
		public LoginBean getUserbyId(int uid) {
			Session sess=sessionFactory.openSession();
			Transaction tx=(Transaction)sess.beginTransaction();
			listUser= sess.createQuery("from UserDetail u where u.uid=:uid").setParameter("uid", uid).list();
		//tx.commit();
		sess.close();
				return listUser.size()>0?listUser.get(0):null;
		}

}
