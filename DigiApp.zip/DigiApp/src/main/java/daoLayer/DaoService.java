package daoLayer;
 
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import model.*;

@Repository
public class DaoService implements DaoInter{
	List<Bean> mdl;
	Bean ms=null;
	
	@Autowired
	SessionFactory sessionFactory;
	public DaoService(){
		       
	} 
	/*public List<Bean> getDetails()
	{
		 mdl = new ArrayList<Bean>();
		 Bean ms=new Bean(222,"VanillaCapuchino");
		 Bean ms1=new Bean(333,"TodaysSpecial");
		 Bean ms2=new Bean(444,"TodaysSpecial");
		 		
		mdl.add(ms);
		mdl.add(ms1);
		mdl.add(ms2);
			
		return mdl; 
		return null;
	}
	public List<Bean> getData(String value) {
		 mdl = new ArrayList<Bean>();
		 //int val=Integer.parseInt(value);
		if(value.equals("222"))
		{
		ms=new	Bean(222,"Teddy Dolls");
		}
		else if(value.equals("333"))
		{
		ms=new	Bean(333,"Teddy Wears");
		}
		else if(value.equals("444"))
		{
		ms=new	Bean(444,"Teddy Candys");
		} 
		mdl.add(ms);
		return mdl;
		
	}*/
	public void addProd(Bean bean) {
		//sessionFactory.openSession().save(bean);
		Session s=sessionFactory.openSession();
		Transaction tx = (Transaction)s.beginTransaction();
		System.out.println("Before Save");
		s.save(bean); 
		System.out.println("After Save");
		tx.commit();
	}

	public int updateProd(Bean bean) { 
		Session session = sessionFactory.openSession();
	    Transaction tx = (Transaction) session.beginTransaction();
	    session.saveOrUpdate(bean);
	    tx.commit();
	    Serializable id = session.getIdentifier(bean);
	    //session.close();
	    return (Integer)id;
		//sessionFactory.getCurrentSession().update(bean); 
	}
	
	public List<Bean> listProds() {
		//return sf.getCurrentSession().createQuery("from Bean").list();
		 Session session = sessionFactory.getCurrentSession();  
		    Query q =session.createQuery("from Bean");
		    	mdl =(List<Bean>)q.list();
		    	return mdl;
	}
	public Bean getProdById(Integer bid) {
		Session session = sessionFactory.openSession();
	    Bean p = (Bean) session.load(Bean.class, bid);
	    return p;
		/*Session s=sessionFactory.getCurrentSession();
		List<Bean> list=s.createQuery("from Bean b where b.pid = :bid").setParameter("pid",bid).list();
		return list.size() > 0 ?(Bean)list.get(0): null;*/
	} 
	public int removeProd(Integer bid) {
		/*Bean b=(Bean)sf.getCurrentSession().load(Bean.class, bid);
		if(null!=b)
		{
			sf.getCurrentSession().delete(b);
		} */
		 Session session = sessionFactory.openSession();
		    Transaction tx = session.beginTransaction();
		    Bean b = (Bean)session.load(Bean.class, bid);
		    session.delete(b);
		    tx.commit();
		    Serializable ids = session.getIdentifier(b);
		    //session.close();
		    return (Integer)ids;
		   
	}
	
}
