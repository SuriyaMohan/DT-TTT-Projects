package com.suriya.controller;

import java.util.*;
import java.util.List;

public class DAOImpl implements DAOInter{

	List<ModalService> mdl;
	ModalService ms=null;
	
	public DAOImpl(){
/*
		ModalService p1=new ModalService();
		p1.setId(222);
		p1.setName("VanillaCapuchino");
		
		ModalService p2=new ModalService();
		p2.setId(333);
		p2.setName("TodaysSpecial");
		
		ModalService p3=new ModalService();
		p3.setId(444);
		p3.setName("Combo");
		
		ModalService p4=new ModalService();
		p4.setId(555);
		p4.setName("Capuchino");
		
		mdl.add(p1);
		mdl.add(p2);
		mdl.add(p3);
		mdl.add(p4);
		*/

	}
	public List<ModalService> getDetails()
	{
		 mdl = new ArrayList<ModalService>();
		ModalService ms=new ModalService("222","VanillaCapuchino");
		ModalService ms1=new ModalService("333","TodaysSpecial");
		ModalService ms2=new ModalService("444","TodaysSpecial");
		ModalService ms3=new ModalService("555","Capuchino");
		
		mdl.add(ms);
		mdl.add(ms1);
		mdl.add(ms2);
		mdl.add(ms3);
		
		return mdl;
	}
	public List<ModalService> getData(String value) {
		 mdl = new ArrayList<ModalService>();
		 //int val=Integer.parseInt(value);
		if(value.equals("222"))
		{
		ms=new	ModalService("222","VanillaCapuchino");
		}
		else if(value.equals("333"))
		{
		ms=new	ModalService("333","TodaysSpecial");
		}
		else if(value.equals("444"))
		{
		ms=new	ModalService("444","Combo");
		}
		else if(value.equals("555"))
		{
		ms=new	ModalService("555","Capuchino");
		}
		mdl.add(ms);
		return mdl;
	}
}
