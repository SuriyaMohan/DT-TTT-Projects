package com.suriya.controller;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;

@Controller
public class NavController {
	
	List<ModalService>  list=new ArrayList<ModalService>();
	DAOImpl dmp=new DAOImpl();
	String s="";
	@RequestMapping("ViewProducts")
	public ModelAndView showMessage(@RequestParam(value="prodId") String name,HttpServletRequest request)
			{
		ModelAndView mv =null;
		s=name;
		mv=new ModelAndView("ViewDetails");
		/*if(name.equals("asd")){
			mv=new ModelAndView("ViewDetails");
		}
		if(name.equals(222))
		 {
			mv=new ModelAndView("ViewDetails");
			request.setAttribute("mylist", list);
			
		 }
		if(name.equals(333))
		 {
			mv=new ModelAndView("ViewDetails");
			request.setAttribute("mylist", list);
			//mv.addObject("id", "333");
			//mv.addObject("name", "TodaysSpecial");
		 }
		if(name.equals(444))
		 {
			mv=new ModelAndView("ViewDetails");
			request.setAttribute("mylist", list);
			//mv.addObject("id", "444");
			//mv.addObject("name", "Combo");
		 }
		if(name.equals(555))
		 {
			mv=new ModelAndView("ViewDetails");
			request.setAttribute("mylist", list);
			//mv.addObject("id", "555");
			//mv.addObject("name", "Capuchino");
		 }*/
		return mv;
	}
	@RequestMapping("moreInfo")
	public ModelAndView moreInfo(){
		ModelAndView mv=new ModelAndView("product");
		return mv;
	}
	
	@RequestMapping("Products")
	public @ResponseBody String productDetails()
	{
		//int value = Integer.parseInt(s);
		if(s.equals("222")||s.equals(333)||s.equals(444)||s.equals(555)){
			list=dmp.getData(s);
		}
		if(s.equals("asd")){
		
			list=dmp.getDetails();
		}
		Gson gs=new Gson();
		String val=gs.toJson(list);
	    return val;
	}
}
