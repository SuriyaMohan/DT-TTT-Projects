package com.suriya.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class NavController {
	@RequestMapping("ViewProducts")
	public ModelAndView showMessage(@RequestParam(value="prodId", defaultValue="admin") String name) throws Exception
			{
		ModelAndView mv =null;
		if(name.equals("222"))
		 {
			mv=new ModelAndView("product");
			mv.addObject("id", "222");
			mv.addObject("name", "VanillaCapuchino");
		 }
		if(name.equals("333"))
		 {
			mv=new ModelAndView("product");
			mv.addObject("id", "333");
			mv.addObject("name", "TodaysSpecial");
		 }
		if(name.equals("444"))
		 {
			mv=new ModelAndView("product");
			mv.addObject("id", "444");
			mv.addObject("name", "Combo");
		 }
		if(name.equals("555"))
		 {
			mv=new ModelAndView("product");
			mv.addObject("id", "555");
			mv.addObject("name", "Capuchino");
		 }
		return mv;
	}
	
	@RequestMapping("SearchProducts")
	public ModelAndView loginMessage(@RequestParam(value="user", defaultValue="admin") String name) throws Exception
			{
		ModelAndView mv = new ModelAndView("ViewDetails");
		mv.addObject("user","WELCOME  " +  name);
		return mv;
	}
}
