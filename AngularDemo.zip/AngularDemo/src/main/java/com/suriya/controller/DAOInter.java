package com.suriya.controller;

import java.util.List;

public interface DAOInter {
	public List<ModalService> getData(String val);
	public List<ModalService> getDetails();
}
