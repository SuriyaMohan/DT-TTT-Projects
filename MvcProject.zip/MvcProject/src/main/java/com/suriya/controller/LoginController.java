package com.suriya.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@RequestMapping("hello")
	public ModelAndView showMessage(HttpServletRequest request,HttpServletResponse response) throws Exception
			{
		ModelAndView mv = new ModelAndView("SignIn");
		return mv;
	}
	
	@RequestMapping("SignUp")
	public ModelAndView register(HttpServletRequest request,HttpServletResponse response) throws Exception
			{
		ModelAndView mv = new ModelAndView("SignUp");
		return mv;
	} 
	
	@RequestMapping("login")
	public ModelAndView loginMessage(@RequestParam(value="user", defaultValue="admin") String name) throws Exception
			{
		ModelAndView mv = new ModelAndView("Success");
		mv.addObject("user","WELCOME  " +  name);
		return mv;
	}
}

