package com.musichub.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="Products")
public class Products {
	@Id
	private String pid;
	private String pname;
	private String pprice;
	private String pdescription;
	public Products(){
		 
	}

	public String getPid() {
	return pid;
}

	public void setPid(String pid) {
	this.pid = pid;
}

	public String getPname() {
	return pname;
}

	public void setPname(String pname) {
	this.pname = pname;
}

	public String getPprice() {
	return pprice;
}

	public void setPprice(String pprice) {
	this.pprice = pprice;
}

	public String getPdescription() {
	return pdescription;
}

	public void setPdescription(String pdescription) {
	this.pdescription = pdescription;
}
	
}
