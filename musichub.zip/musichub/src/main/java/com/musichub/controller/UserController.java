package com.musichub.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.musichub.daoLayer.UserDaoInter;
import com.musichub.model.RegUser;
import com.musichub.model.UserDetail;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.stereotype.Controller;

@Controller
public class UserController {
	
	@Autowired
	UserDaoInter uds; 

	@RequestMapping("/adminView")
	public ModelAndView adminView()
	{
		return new ModelAndView("success");  
	}
	//Registration Page
	@RequestMapping("/UserRole")
	public ModelAndView assignRoles()
	{
		return new ModelAndView("UserRole"); 
	}
	@ModelAttribute("user")//This refers to command name which we gave 
	public UserDetail createUser()
	{
		return new UserDetail();//creating a model object
	}

	@RequestMapping(value={"/userMap"},method=RequestMethod.POST)
	public ModelAndView addingUser(@ModelAttribute("user") UserDetail user)
	{
		
		uds.addUser(user);
		return new ModelAndView("success");  
	}
	//authentication code
	 
	@RequestMapping(value = {"/welcome**"}, method = RequestMethod.GET)
	public ModelAndView defaultPage() {

	  ModelAndView model = new ModelAndView("success");
	  //model.addObject("title", "Spring Security Login Form - Database Authentication");
	  //model.addObject("message", "This is default page!");
	  //model.setViewName("index");
	  return model;
	}
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = "error", required = false) String error,
		@RequestParam(value = "logout", required = false) String logout) { 
	  ModelAndView model = new ModelAndView(); 
	   if (error != null) {
		model.addObject("error", "Invalid username and password!");
	  } 

	  if (logout != null) {
		model.addObject("msg", "You've been logged out successfully.");
	  }
	  model.setViewName("login"); 
	  return model;  
 
	}
		@RequestMapping(value = "/admin**", method = RequestMethod.POST)
	public ModelAndView adminPage() {

	  ModelAndView model = new ModelAndView();
	  model.addObject("title", "Spring Security Login Form - Database Authentication");
	  model.addObject("message", "This page is for ROLE_ADMIN only!");
	  model.setViewName("admin"); 
	  return model;

	} 
		//for 403 access denied page
	/*@RequestMapping(value = "/denied", method = RequestMethod.POST)
			public ModelAndView accesssDenied() {

			  ModelAndView model = new ModelAndView();
				
			  //check if user is login
			  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			  if (!(auth instanceof AnonymousAuthenticationToken)) {
				UserDetails userDetail = (UserDetails) auth.getPrincipal();	
				model.addObject("username", userDetail.getUsername());
			  } 

			  model.setViewName("userdenied");
			  return model;
 
			}*/
}
