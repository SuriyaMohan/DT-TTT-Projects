package com.musichub.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.google.gson.Gson;
import com.musichub.model.Products;
import com.musichub.serviceLayer.ProdServiceInter;

@Controller
public class IndexController {
 
	String s="";
	List<Products>  list=new ArrayList<Products>();
			
	@Autowired 
	ProdServiceInter ps; 
	public IndexController(){
		 
	} 
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	@RequestMapping("signup")
	public ModelAndView sigUp()throws Exception
			{
		ModelAndView mv = new ModelAndView("signup");
		return mv;
	}
	@RequestMapping(value="/listprod", method = RequestMethod.GET)
	 public ModelAndView listEmployees() {
	      list=ps.listProds();
		 return new ModelAndView("list","products", list); 
	 }
	 @RequestMapping(value = "/addProd", method = RequestMethod.GET)
	 public ModelAndView addProduct(@ModelAttribute("command") Products command) {
	  Map<String, Object> model = new HashMap<String, Object>();
	  model.put("products", ps.listProds());
	  return new ModelAndView("add", model);   
	 } 
	 @ModelAttribute("pro")
	 public @ResponseBody Products createProduct()
	 { 
		 return new Products(); 
	 }
	 	
	 @RequestMapping(value = "save", method = RequestMethod.POST) 
	 public ModelAndView saveProduct(@ModelAttribute("pro") Products pro, HttpServletRequest request,BindingResult result) {
		 ps.addProd(pro);//calls service method
		 System.out.println("Added");
		 return new ModelAndView("redirect:/addProd");
	 } 
	 String assign="";
	 @RequestMapping(value = "/edit", method = RequestMethod.GET)
	 public ModelAndView editProduct(@RequestParam String id,@ModelAttribute("m") Products user, BindingResult result) throws Exception {
	 //System.out.println("Inside Edit" + user.getPid()+""+user.getPname()+""+user.getPdescription()+""+user.getPprice());
		 assign=id; 
		 Products pdt=ps.getProdById(id);
		 return new ModelAndView("prodUpdate","pdt",pdt);  
	 }
	 @RequestMapping(value = "/update", method = RequestMethod.POST)
	 public ModelAndView updateProduct(@ModelAttribute("m") Products user) throws Exception {
		 //System.out.println("Inside Update" + user.getPid()+""+user.getPname()+""+user.getPdescription()+""+user.getPprice());
		 user.setPid(assign);
		 ps.updateProd(user);
		 System.out.println("Edited");
		 return new ModelAndView("products");  
	 } 
	  
	 @RequestMapping(value = "/delete2", method = RequestMethod.GET) 
	 public ModelAndView deleteProduct(@RequestParam String id,@ModelAttribute("m") Products m,BindingResult result)throws Exception 
	 {
		// System.out.println(m.getPid() + " "+ m.getPname() + " " + m.getPprice()+" "+ m.getPdescription());
		 ps.removeProd(id);   
		 System.out.println("deleted successfully");
	       return new ModelAndView("success");
	 }
	 @RequestMapping("moreInfo")
		public ModelAndView infoPage()throws Exception
				{
			ModelAndView mv = new ModelAndView("products");
			return mv;
		}
	 @RequestMapping("prodesc")
		public ModelAndView showMessage(@RequestParam String a)throws Exception
				{
		 s=a;

		 ModelAndView mv = new ModelAndView("viewProducts");
			return mv;
		}
	 @RequestMapping("Products")
	 public @ResponseBody String productDetails()
	 {
		 if(s.equals("222")||s.equals("333")||s.equals("444")){
			 List<Products> list=new ArrayList<Products>();
		 	//Products p=ps.getProdById(Integer.parseInt(s));
			 Products p=ps.getProdById(s);
			list.add(p);
		}
		if(s.equals("asd")){
			List<Products> list=new ArrayList<Products>();
			list=ps.listProds();
		}
		   
		Gson gs=new Gson(); 
		String val=gs.toJson(list);
	    return val;
	} 
}
 