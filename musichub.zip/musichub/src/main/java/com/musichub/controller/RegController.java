package com.musichub.controller;

import java.util.ArrayList;
import java.util.List;

//import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import javax.validation.Valid;
import com.musichub.model.RegUser;

@Controller
@RequestMapping(value="/signUp")  
public class RegController {
	
	List<RegUser> regUser=new ArrayList<RegUser>();
	@RequestMapping(method=RequestMethod.GET)
    public String showForm(ModelMap model){
		RegUser user = new RegUser();
        model.addAttribute("USER", user);
        return "signup";
    }

    @RequestMapping(method=RequestMethod.POST) //@Valid
    public String processForm(@ModelAttribute(value="USER")  RegUser user,BindingResult result){
        if(result.hasErrors()){ 
        	            return "signup"; 
        }else{
        	regUser.add(user);
            return "login";
        }
    }


}
