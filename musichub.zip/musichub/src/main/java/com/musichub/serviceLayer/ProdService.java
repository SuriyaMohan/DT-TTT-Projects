package com.musichub.serviceLayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.musichub.daoLayer.DaoProdInter;
import com.musichub.model.Products;

@Service
public class ProdService implements ProdServiceInter{

	@Autowired
	DaoProdInter pds;
	public ProdService()
	{ 
		  
	}
	public void addProd(Products prod) {
		pds.addProd(prod);
	}

	public void updateProd(Products prod)throws Exception {
		 pds.updateProd(prod); 
	}

	public List<Products> listProds() {
		return pds.listProds();
	}

	public Products getProdById(String bid) {
		return pds.getProdById(bid);
	}
 
	public void removeProd(String id)throws Exception {
		pds.removeProd(id);
	}
}
