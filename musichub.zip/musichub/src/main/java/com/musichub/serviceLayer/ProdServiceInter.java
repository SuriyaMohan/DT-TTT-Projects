package com.musichub.serviceLayer;

import java.util.List;

import com.musichub.model.Products;

public interface ProdServiceInter {
	public void addProd(Products prod);
    public void updateProd(Products prod)throws Exception;
    public List<Products> listProds(); 
    public Products getProdById(String bid);
    public void removeProd(String prod)throws Exception; 
 
}
