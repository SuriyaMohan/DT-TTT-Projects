package com.musichub.serviceLayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.musichub.daoLayer.UserDaoInter;
import com.musichub.model.UserDetail;

@Service 
public class UserServiceImpl implements UserServiceInter {

	@Autowired  
	UserDaoInter uds;
	@Override
	public void addUser(UserDetail ud) {
		uds.addUser(ud);		
	}

	@Override
	public void updateUser(UserDetail ud) {
		uds.updateUser(ud);
	}

	@Override
	public void removeUser(int uid) {
		uds.removeUSer(uid);
	}

	@Override
	public List<UserDetail> listUser() {
		return uds.getUser();
	}

	@Override
	public UserDetail getUserbyId(int uid) {
		return uds.getUserbyId(uid);
	}

}
