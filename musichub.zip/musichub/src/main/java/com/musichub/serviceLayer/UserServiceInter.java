package com.musichub.serviceLayer;

import java.util.List;

import com.musichub.model.UserDetail;

public interface UserServiceInter {
	public void addUser(UserDetail ud);
	public void updateUser(UserDetail ud);
	public void removeUser(int uid);
	public List<UserDetail> listUser();
	public UserDetail getUserbyId(int uid);
}
 