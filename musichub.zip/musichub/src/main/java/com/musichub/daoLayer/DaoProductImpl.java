package com.musichub.daoLayer;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.musichub.model.Products;

@Repository
@Transactional
public class DaoProductImpl implements DaoProdInter{
 
	public DaoProductImpl(){
		 
	} 
	@Autowired
	SessionFactory sessionFactory;
	
	public void addProd(Products bean) {
		Session session = sessionFactory.getCurrentSession();
		System.out.println("before added");
		session.saveOrUpdate(bean);
		System.out.println("after added");
		session.flush();
	}

	public void updateProd(Products bean) throws Exception {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(bean);
        session.flush();
	} 
 
	public List<Products> listProds() {
		Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Products");
        List<Products> itemList = query.list();
        session.flush();
        return itemList;
        }

	public Products getProdById(String id) { 
		 Session session = sessionFactory.getCurrentSession();
	        Products item = (Products) session.get(Products.class, id);
	        session.flush();
	        return item;
	        }
 
	public void removeProd(String gid)throws Exception { 
		 Session session = sessionFactory.getCurrentSession();
		 Products m=(Products)session.load(Products.class,gid );
	        session.delete(m); 
	        session.flush(); 
	} 

}
