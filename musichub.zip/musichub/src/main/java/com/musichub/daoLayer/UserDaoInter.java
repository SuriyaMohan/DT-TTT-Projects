package com.musichub.daoLayer;

import java.util.List;

import com.musichub.model.UserDetail;

public interface UserDaoInter {

	public void addUser(UserDetail ud);
	public void updateUser(UserDetail ud);
	public void removeUSer(int uid);
	public List<UserDetail> getUser();
	public UserDetail getUserbyId(int uid);
	
}
