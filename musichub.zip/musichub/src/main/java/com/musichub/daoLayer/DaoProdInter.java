package com.musichub.daoLayer;

import java.util.List;

import com.musichub.model.Products; 

public interface DaoProdInter {
	  public void addProd(Products bean);
	    public void updateProd(Products bean)throws Exception;
	    public List<Products> listProds();
	    public Products getProdById(String bid);
	    public void removeProd(String gid)throws Exception;
  
}
