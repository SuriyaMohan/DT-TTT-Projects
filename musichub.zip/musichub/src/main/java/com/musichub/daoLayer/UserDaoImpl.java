package com.musichub.daoLayer;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.musichub.model.UserDetail;

@Repository
@Transactional 
public class UserDaoImpl implements UserDaoInter {
	
	@Autowired
	SessionFactory sessionFactory; 
	@Override
	public void addUser(UserDetail ud) {
		Session session = sessionFactory.getCurrentSession();
		System.out.println("before added");
		session.saveOrUpdate(ud);
		System.out.println("after added");
		session.flush(); 
		
	}

	@Override
	public void updateUser(UserDetail ud) {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(ud);
        session.flush();
		
	}

	@Override
	public void removeUSer(int uid) {
		 Session session = sessionFactory.getCurrentSession();
		 UserDetail m=(UserDetail)session.load(UserDetail.class,uid );
	        session.delete(m); 
	        session.flush(); 
		
	}

	@Override
	public List<UserDetail> getUser() {
		Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from UserDetail");
        List<UserDetail> userList = query.list();
        session.flush();
        return userList;
        
	}

	@Override
	public UserDetail getUserbyId(int uid) {
		Session session = sessionFactory.getCurrentSession();
		UserDetail item = (UserDetail) session.get(UserDetail.class, uid);
        session.flush();
        return item;
	}

}
